# Contribute

To contribute with the project, clone it, create a virtualenv and install all of you need to dev, see below:

```bash
git clone https://github.com/flask-extensions/Flask-GoogleMaps.git
cd Flask-GoogleMaps
poetry use env 3.8  # just to create virtualenv at the first time
poetry shell # activate virtualenv
poetry install  # to install all for dev
```
