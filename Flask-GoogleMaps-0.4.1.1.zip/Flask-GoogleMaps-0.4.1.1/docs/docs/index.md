# Introduction

This lib is an easy way to use Google Maps in your Flask application.

# requires

- Python 3.6+
- Jinja
- Flask 1.0.0+
- A google api key [get here](https://developers.google.com/maps/documentation/javascript/get-api-key)
