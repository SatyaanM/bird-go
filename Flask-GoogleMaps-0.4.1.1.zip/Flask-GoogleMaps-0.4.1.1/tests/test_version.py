from flask_googlemaps import __version__


def test_version():
    assert __version__ == "0.4.1"
